classdef  NGra_twistedhBN
    %

    properties
        Name
        Lattice_constant %of the active layer
        Potential_phase  %of the hBN/Gra moire potential
        Potential_strength
        Q_cut            % of plane wave basis
        Lm            %
        Nlayer
        Valley
        Align
        Delta
        Hop   
        Q0
        Bfield
        Alpha
    end
    methods
        function obj = NGra_twistedhBN(name,phase,V,q_cut,lm,N,valley,align,delta,hop,bfield)
            %Generate the object with given parameter
            %{
               Name: the name of the system you choose
               Lattice_constant: the lattice constant of one layer
               Q_cut: cut off the plane wave, Nth nearst momentum are kept
               Lattice_mixmatch: =0 if homobilayer
               interlater: the strength of the interlayer coupling
               offset: the band offset for heterobilayer
               Efield: the layer potential difference due to tha electric field D*d/\epsilon
            %}
            obj.Name=name;
            obj.Lattice_constant=2.46; %Graphene constant
            obj.Potential_phase=phase./180*pi;
            obj.Potential_strength=V;
            obj.Q_cut=q_cut;
            obj.Lm=lm;
            obj.Nlayer=N;
            obj.Valley=valley;
            obj.Align=align;
            obj.Delta=delta;
            obj.Hop=hop; 
            obj.Bfield=bfield;
            
        end
        %%%%%%%%%% BASIC INFORMATION OF SYSTEM: BZ AND UNITCELL%%%%%
        function [Gm1,Gm2]=reciprocal_vectors(obj)
            am=obj.Lm;
            % My convenction
            % Gm1=4*pi/sqrt(3)/am.*[sqrt(3),-1]./2;
            % Gm2=4*pi/sqrt(3)/am.*[0,1];
            
            % Yang convention               
            Gm1=4*pi/sqrt(3)/am.*[1,0];
            Gm2=4*pi/sqrt(3)/am.*[-1/2,sqrt(3)/2];

        end
        function [am1,am2]=lattice_vectors(obj)
            am=obj.Lm;
            % My convention
            % am1=[1,0].*am;
            % am2=[1,sqrt(3)]./2.*am;
            % Yang convention
            am1=[0,1].*am;
            am2=[sqrt(3),1]./2.*am;

            
        end
         function Hk=HK(obj,k,valley)
             V1=obj.Potential_strength(2);
            [Gm1,Gm2]=obj.reciprocal_vectors();
            Q=obj.Q0;
           

           
            l=length(Q);
            %1.tb parameter
            t0=obj.Hop(1); %NN hopping
            t1=obj.Hop(2);%adjacentlayer facing hopping
            t2=obj.Hop(3);%seperate layer facing hopping
            t3=obj.Hop(4);%Trigonal Warping
            t4=obj.Hop(5);% Skew interalyer couplinh
            %2. The electric field bring layer difference
            N=obj.Nlayer;
            Ldiff=obj.Delta.*((1-N)/2:(N-1)/2)./(N-1);
            Ldiff=kron(Ldiff,ones(1,2));
            Ldiff=diag(Ldiff);
            %3. Onsite difference
            if N>3
                tip=zeros(1,2*N);
                tip(2)=0.0122;tip(2*N-1)=0.0122;
                tip(3:2*N-2)=-0.0164;
                Honsite=diag(tip).*0;
            else
                Honsite=zeros(2*N,2*N);
            end
            %4. The low energy kp near K
            K=k+Q;
            Hk=[];
            v0=sqrt(3)/2*2.46*abs(t0);
            v3=sqrt(3)/2*2.46*abs(t3);
            v4=sqrt(3)/2*2.46*abs(t4);
            %Seperate layer coupling
            H13=[0,t2;0,0];
            for i1=1:l
                k=K(i1,:);
                k(1)=valley.*k(1);
                Hll=[0,v0*(k(1)-1i*k(2));v0*(k(1)+1i*k(2)),0];
                H12=[-v4*(k(1)-1i*k(2)),-v3*(k(1)+1i*k(2));t1,-v4*(k(1)-1i*k(2))];            
                Htem=matrixpic(N,Hll,H12,H13)+Ldiff+Honsite;
                % Htem(1,1)=Htem(1,1)+V0;Htem(2,2)=Htem(2,2)+V0;
                Hk=blkdiag(Hk,Htem);
            end
            %5.Apply the moire potential
            kpdim=2*N;
            Hoff=zeros(kpdim*l,kpdim*l);
            % My convention
            % AAphase=[1,-1,1,-1,1,-1];
            % ABphase=[-1,1,1,0,0,-1].*2*pi/3;
            % BAphase=[0,0,1,1,-1,-1].*2*pi/3;
            % Yang convention
              AAphase=[1,-1,1,-1,1,-1];
             % ABphase=[-1,1,1,0,0,-1].*2*pi/3;
            % BAphase=[0,0,1,1,-1,-1].*2*pi/3;
       
            psi=obj.Potential_phase(1);

            % alpha=zeros(1,N);
            % alpha=ones(1,N);
            % alpha(1)=1;alpha(2)=0.5;
            alpha=obj.Alpha;
            for i2=1:l
                for j=1:l
                    d=Q(i2,:)-Q(j,:);
                    if abs(norm(d)-norm(Gm1))<=0.001*norm(Gm1)
                        
                        index=dirrep(round(d/([Gm1;Gm2])));
                        Htem=[];
                        H11=V1.*exp(1i*psi*AAphase(index));
                        % H22=V1.*exp(1i*(psi*AAphase(index)-2*pi/3*AAphase(index)));
                        % H12=V1.*exp(1i*(psi*AAphase(index)+ABphase(index)));
                        % H21=V1.*exp(1i*(psi*AAphase(index)+BAphase(index)));
                        % if obj.Align==1
                            % H0=[H11,0;0,H11];
                        % else
                            H0=[H11,0;0,H11];
                        % end
                        for i3=1:N
                            Htem=blkdiag(Htem,H0.*alpha(i3));
                        end
                        
                        % 
                        
                        Hoff(kpdim*i2-kpdim+1:kpdim*i2,kpdim*j-kpdim+1:kpdim*j)=Htem;
                        
                    end

                end
            end
            Hk=Hk+Hoff;
            function index=dirrep(x)
                rep=[1,0;1,1;0,1;-1,0;-1,-1;0,-1];
                for i0=1:6
                    if round(sum(abs(rep(i0,:)-x)))==0
                        index=i0;
                    end
                end   
            end

function H=matrixpic(N,Hll,H12,H13)
            if N==1
                H=Hll;
            elseif N==2
                H=[Hll,H12;H12',Hll] ;
            elseif N>2
                %对角
                Hd=[];
                for i=1:N
                    Hd=blkdiag(Hd,Hll);
                end
                Hdd=[];
                %次对角
                for i=1:N-1
                    Hdd=blkdiag(Hdd,H12);
                end

                Hdd=blkdiag(Hdd,zeros(2,2));
                %次次对角
                Hddd=[];
                for i=1:N-2
                    Hddd=blkdiag(Hddd,H13);
                end
                Hddd=blkdiag(Hddd,zeros(4,4));
                H2=circshift(Hdd,[0,2]);
                H3=circshift(Hddd,[0,4]);
                Hoff1=H2+H3;
                H=Hd+Hoff1+Hoff1';
            end


        end
        end

        function Hk=HK1(obj,k,valley)
            V0=obj.Potential_strength(1);V1=obj.Potential_strength(2);
            [Gm1,Gm2]=obj.reciprocal_vectors();
            Q=obj.Q0;
           

           
            l=length(Q);
            %1.tb parameter
            t0=obj.Hop(1); %NN hopping
            t1=obj.Hop(2);%adjacentlayer facing hopping
            t2=obj.Hop(3);%seperate layer facing hopping
            t3=obj.Hop(4);%Trigonal Warping
            t4=obj.Hop(5);% Skew interalyer couplinh
            %2. The electric field bring layer difference
            N=obj.Nlayer;
            Ldiff=obj.Delta.*((1-N)/2:(N-1)/2)./4;
            Ldiff=kron(Ldiff,ones(1,2));
            Ldiff=diag(Ldiff);
            %3. Onsite difference
            if N>3
                tip=zeros(1,2*N);
                tip(2)=0.0122;tip(2*N-1)=0.0122;
                tip(3:2*N-2)=-0.0164;
                Honsite=diag(tip).*0;
            else
                Honsite=zeros(2*N,2*N);
            end
            %4. The low energy kp near K
            K=k+Q;
            Hk=[];
            v0=sqrt(3)/2*2.46*abs(t0);
            v3=sqrt(3)/2*2.46*abs(t3);
            v4=sqrt(3)/2*2.46*abs(t4);
            %Seperate layer coupling
            H13=[0,t2;0,0];
            for i1=1:l
                k=K(i1,:);
                k(1)=valley.*k(1);
                Hll=[0,v0*(k(1)-1i*k(2));v0*(k(1)+1i*k(2)),0];
                H12=[-v4*(k(1)-1i*k(2)),-v3*(k(1)+1i*k(2));t1,-v4*(k(1)-1i*k(2))];            
                Htem=matrixpic(N,Hll,H12,H13)+Ldiff+Honsite;
                Htem(1,1)=Htem(1,1)+V0;Htem(2,2)=Htem(2,2)+V0;
                Hk=blkdiag(Hk,Htem);
            end
            %5.Apply the moire potential
            kpdim=2*N;
            Hoff=zeros(kpdim*l,kpdim*l);
            % My convention
            % AAphase=[1,-1,1,-1,1,-1];
            % ABphase=[-1,1,1,0,0,-1].*2*pi/3;
            % BAphase=[0,0,1,1,-1,-1].*2*pi/3;
            % Yang convention
              AAphase=[1,-1,1,-1,1,-1];
             ABphase=[-1,1,1,0,0,-1].*2*pi/3;
            BAphase=[0,0,1,1,-1,-1].*2*pi/3;
       
            psi=obj.Potential_phase(1);

            alpha=zeros(1,N);alpha(1)=1;
            for i2=1:l
                for j=1:l
                    d=Q(i2,:)-Q(j,:);
                    if abs(norm(d)-norm(Gm1))<=0.001*norm(Gm1)                        
                        index=dirrep(d);
                        Htem=[];
                        H11=V1.*exp(1i*psi*AAphase(index));
                        H22=V1.*exp(1i*(psi*AAphase(index)-2*pi/3*AAphase(index)));
                        H12=V1.*exp(1i*(psi*AAphase(index)+ABphase(index)));
                        H21=V1.*exp(1i*(psi*AAphase(index)+BAphase(index)));
                        if obj.Align==1
                            H0=[H11,H12;H21,H22];
                        else
                            H0=[H22,H12';H21',H11];
                        end
                        for i3=1:N
                            Htem=blkdiag(Htem,H0.*alpha(i3));
                        end
                        
                        
                        Hoff(kpdim*i2-kpdim+1:kpdim*i2,kpdim*j-kpdim+1:kpdim*j)=Htem;
                        
                    end

                end
            end
            Hk=Hk+Hoff;
            function index=dirrep(x)
                % My convention
                % list=[1/6,1/2,5/6,-5/6,-1/2,-1/6];
                % Yang convention                                                            
                  list=[0,1/3,2/3,1,-2/3,-1/3];
                [~,index]=find(round(6*abs((list-dir(x)/pi)))==0);
                function phi=dir(x)
                    phi=angle(x(1)+1i*x(2));
                end
            end

function H=matrixpic(N,Hll,H12,H13)
            if N==1
                H=Hll;
            elseif N==2
                H=[Hll,H12;H12',Hll] ;
            elseif N>2
                %对角
                Hd=[];
                for i=1:N
                    Hd=blkdiag(Hd,Hll);
                end
                Hdd=[];
                %次对角
                for i=1:N-1
                    Hdd=blkdiag(Hdd,H12);
                end

                Hdd=blkdiag(Hdd,zeros(2,2));
                %次次对角
                Hddd=[];
                for i=1:N-2
                    Hddd=blkdiag(Hddd,H13);
                end
                Hddd=blkdiag(Hddd,zeros(4,4));
                H2=circshift(Hdd,[0,2]);
                H3=circshift(Hddd,[0,4]);
                Hoff1=H2+H3;
                H=Hd+Hoff1+Hoff1';
            end


        end
        end

function Hk=HAK(obj)
            [Gm1,~]=obj.reciprocal_vectors();
           
            % [Q1,~]=obj.Q_position();  
            Q=obj.Q0;
            lm = obj.Lm;
            N=obj.Nlayer;
            l=length(Q);
            vF=abs(obj.Hop(1))*sqrt(3)/2*2.46; %NN hopping
            gamma=obj.Bfield(1)*vF/lm;
            phi=obj.Bfield(2);
            kpdim=2*N;
            Hoff=zeros(kpdim*l,kpdim*l);            
             for i=1:l
                for j=1:l
                    if i<j
                        d=Q(i,:)-Q(j,:);
                        if abs(norm(d)-norm(Gm1))<=0.001*norm(Gm1)
                          if dirrep(d)==1
                            Htem=zeros(2*N,2*N);
                            Htem(1,2)=gamma*exp(-1i*phi)/2*1i;
                            Htem(2,1)=gamma*exp(-1i*phi)/2*1i;
                            Hoff(kpdim*i-kpdim+1:kpdim*i,kpdim*j-kpdim+1:kpdim*j)=Htem;
                          elseif dirrep(d)==2
                            Htem=zeros(2*N,2*N);
                            Htem(1,2)=gamma*exp(1i*phi)/4*(1i-sqrt(3));
                            Htem(2,1)=gamma*exp(1i*phi)/4*(1i+sqrt(3));
                            Hoff(kpdim*i-kpdim+1:kpdim*i,kpdim*j-kpdim+1:kpdim*j)=Htem;
                          elseif dirrep(d)==3
                            Htem=zeros(2*N,2*N);
                            Htem(1,2)=-gamma*exp(-1i*phi)/4*(1i+sqrt(3));
                            Htem(2,1)=gamma*exp(-1i*phi)/4*(sqrt(3)-1i);
                            Hoff(kpdim*i-kpdim+1:kpdim*i,kpdim*j-kpdim+1:kpdim*j)=Htem;
                          elseif dirrep(d)==4
                            Htem=zeros(2*N,2*N);
                            Htem(1,2)=-gamma*exp(1i*phi)/2*1i;
                            Htem(2,1)=-gamma*exp(1i*phi)/2*1i;;
                            Hoff(kpdim*i-kpdim+1:kpdim*i,kpdim*j-kpdim+1:kpdim*j)=Htem;
                           elseif dirrep(d)==5
                            Htem=zeros(2*N,2*N);
                            Htem(1,2)=gamma*exp(-1i*phi)/4*(sqrt(3)-1i);
                            Htem(2,1)=-gamma*exp(-1i*phi)/4*(sqrt(3)+1i);
                            Hoff(kpdim*i-kpdim+1:kpdim*i,kpdim*j-kpdim+1:kpdim*j)=Htem;
                           elseif dirrep(d)==6
                            Htem=zeros(2*N,2*N);
                            Htem(1,2)=gamma*exp(1i*phi)/4*(sqrt(3)+1i);
                            Htem(2,1)=gamma*exp(1i*phi)/4*(1i-sqrt(3));
                            Hoff(kpdim*i-kpdim+1:kpdim*i,kpdim*j-kpdim+1:kpdim*j)=Htem;
                           end
                        end
          
                    end
          
                end
            end
            Hk=Hoff+Hoff';
            function index=dirrep(x)
                % My convention
                % list=[1/6,1/2,5/6,-5/6,-1/2,-1/6];
                % Yang convention
                list=[0,1/3,2/3,1,-2/3,-1/3];
                [~,index]=min(abs((list-dir(x)/pi)));
                function phi=dir(x)
                    phi=angle(x(1)+1i*x(2));
                end    
            end
          end

    
    %%#############  SLOVE THE HAMILITONIAN%%%%%%%%%%%%   
    function [E,Psik]=solve_kpoint(obj,k)
            [Gm1,Gm2]=obj.reciprocal_vectors();          
      q1=(Gm1-Gm2)/3+Gm2;
      if obj.Valley==1
        
        Hk=obj.HK(k+q1,1);
        % Hk=obj.HK(k,1);
        elseif obj.Valley==-1
            
            Hk=conj(obj.HK(q1-k,1));
        else
        Hk1=obj.HK(k+q1,1);
        % Hk2=obj.HK(k-q1,-1);
        Hk2=conj(obj.HK(q1-k,1));
        Hk=blkdiag(Hk1,Hk2);
    end
    [V,D]=eig(Hk);
    [E,ind]=sort(diag(D));
    Psik=V(:,ind);
 end
    
function [E,Psik]=solve_kpointss(obj,k)
            [Gm1,Gm2]=obj.reciprocal_vectors();          
      q1=(Gm1-Gm2)/3+Gm2;
        if obj.Valley==1        
        Hk=obj.HK(k,1);
        elseif obj.Valley==-1
            
            Hk=conj(obj.HK(q1-k,1));
        else
        Hk1=obj.HK(k+q1,1);
        % Hk2=obj.HK(k-q1,-1);
        Hk2=conj(obj.HK(q1-k,1));
        Hk=blkdiag(Hk1,Hk2);
        end
    [V,D]=eig(Hk);
    [E,ind]=sort(diag(D));
    Psik=V(:,ind);
 end
    end
    methods(Static)
    
    end
end