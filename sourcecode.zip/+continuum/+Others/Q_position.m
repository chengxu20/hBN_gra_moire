function [Q_1, Q_2,q1,q2,q3] = Q_position(Lm,cutoff,shift)
% 2023-10-19
            %Generate the plane basis accdording "Bernevig, B. A.; Song, Z.-D.;
            % Regnault, PHYSICAL REVIEW B 2021,103 (20)."
            %{
           a: the lattice constant [\AA]
           N: the cutoff of the shell in <TBG.I>
           theta: the rotation angle between the layers
           Q_1: the plane wave momentum of layer 1
           Q_2: the plane wave momentum of layer 2
            %}
            %             theta = obj.Theta;
            a = Lm;
            N = cutoff;
            k_D=4*pi./3/a; % The amplitude of the coupling momentum
            q1=k_D*[0 1];q2=k_D*[-sqrt(3)/2 -0.5];q3=k_D*[sqrt(3)/2 -0.5];theta1=pi/3;
            %matrix used to store QA
            QA = cell(1, N);

            for n = 1:N
                QA{n} = zeros(6 * n, 2);
            end

            QB = QA;
            %All of sites in the sub-shell A in region 1
            for n = 1:N
                TEM = QA{n};

                for j = 1:n
                    TEM(j, :) = q1 + (n - 1) .* (q1 - q2) + (j - 1) .* (q2 - q3);
                end

                QA{n} = TEM; %The sites in subshell An
            end

            %The left 5 class of QA
            for n = 1:N
                TEM = QA{n};

                for j = 1:5
                    TEM(j * n + 1:(j + 1) * n, :) = ([cos(j * theta1) -sin(j * theta1); sin(j * theta1) cos(j * theta1)] * TEM(1:n, :).').';
                end

                QA{n} = TEM;
            end

            %All of QBfic
            Q = [q1; -q3; q2; -q1; q3; -q2];

            for n = 1:N
                TEMA = QA{n};
                TEMB = QB{n};

                for i = 0:5
                    TEMB(i * n + 1:(i + 1) * n, :) = TEMA(i * n + 1:(i + 1) * n, :) + Q(i + 1, :);
                end

                QB{n} = TEMB;
            end

            Q1 = cell(1, N);
            Q2 = cell(1, N);

            for i = 1:N

                for j = [1, 3, 5]
                    Q1{i} = [Q1{i}; QA{i}(i * (j - 1) + 1:j * i, :)];
                    Q2{i} = [Q2{i}; QB{i}(i * (j - 1) + 1:j * i, :)];
                end

                for j = [2, 4, 6]
                    Q1{i} = [Q1{i}; QB{i}(i * (j - 1) + 1:j * i, :)];
                    Q2{i} = [Q2{i}; QA{i}(i * (j - 1) + 1:j * i, :)];
                end

            end

            Q_1 = []; Q_2 = [];

            for i = 1:N
                Q_1 = [Q_1; Q1{i}];
            end

           Q_2=-Q_1;
           if shift==1
            Q_1=Q_1-q1;
            C90=[0,-1;1,0];
            Q_1=(C90*Q_1')';
            Q_2=(C90*Q_2')';
            l=length(Q_1);

            for i=l:-1:1

                if norm(Q_1(i,:))>(N-1)*k_D*sqrt(3)+0.001*norm(Q_1(2,:))

                    Q_1(i,:)=[];
                end
            end
            Q_2=Q_1;
           end
           % Q_1=unique(Q_1,'rows');
           % Q_2=unique(Q_2,'rows');
            % C30=[sqrt(3)/2,-1/2;1/2,sqrt(3)/2];
            % Q_1=(C30*Q_1')';


        end
