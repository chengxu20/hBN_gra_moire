function [bands,Unk]=band_solve(obj,Kpath,dim_H)
%2023-10-19           
%band_solve : slove the band-structure along the given k-path
%obj:continumm model object
%dim_H: dimension of Hamiltonian
%Kpath: position of the kpath
%Unk: eigenstates  Norbit*Nband*knum*knum 
            knum=length(Kpath);%the number of k-pionts we need to calculate along the high-symmetry path
            E=zeros(knum,dim_H);%the matrix to store the band
            Unk=zeros(dim_H,dim_H,knum);
            slovek=@(obj,k) obj.solve_kpoint(k);
            for i=1:knum
                k=Kpath(i,:);%the momentum we calculate now                
                [e, psi] = slovek(obj,k);
                E(i,:)=e;
                Unk(:,:,i)=psi;
            end
            bands=E;
end