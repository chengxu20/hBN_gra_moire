 function bands_plot(bands,type,point_labels,Kindex)
 % date: 2023-10-19 
            %bands Norbits*Nbands: the bands information
            %type: format:{"line","color","linewidth"} eg:{"line","k",2} or
            %{"dot","k","marker","markersize"}
            figure('Color','white')
               
            if type{1}=="line"
                plot(bands,"LineStyle","-","Color",type{2},"LineWidth",type{3});
            elseif type{2}=="dot"
                plot(bands,"Color",type{2},"Maker",type{3},"Makersize",type{4});
            end
            xticks(Kindex)
            xticklabels(point_labels)
            Num_high_sym=length(Kindex);
            Newindex=Kindex(2:Num_high_sym-1);
            xline(Newindex,LineWidth=1,LineStyle="--")
            yline(0,LineWidth=1,LineStyle="--")
            ylabel('E(eV)','Interpreter','latex')
            xlim([Kindex(1),Kindex(end)])           
            set(gca,'Fontsize',20,'FontName','Times New Roman','linewidth',0.8)
end