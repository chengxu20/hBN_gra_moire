function [Eaxis,Dos,dE]=calc_dos(En,c,Enum,Emin,Emax,Nband,plottap)
% 2023-10-19
            %{
                 c: the broadening of Gaussian broadening
                 En:knum*knum*Nband the energy spectrum of the bands
                 Enum: number of energy we will calculate

            %}
            En=En(:);
            Eaxis=linspace(Emin,Emax,Enum);
            Dos=zeros(1,Enum);
            for i=1:Enum
                E=Eaxis(i);
                Dos(i)=1/(c*sqrt(2*pi))*sum(exp((-(En-E).^2)./(2*c*c)));
            end
            C=sum(Dos)*(Emax-Emin)/(Enum-1);
            Dos=Dos./C.*Nband;
            dE=(Emax-Emin)/(Enum-1);
            if plottap==1
            figure('Color','white')
            % plot(Eaxis,Dos,'k-')
            plot(Eaxis,Dos,'Linestyle','-','Color','#4DA1D7','LineWidth',2)
            xlabel('E(eV)')
            ylabel('Dos')
            set(gca,'Fontsize',20,'FontName','Times New Roman','linewidth',0.8)
            end
        end
