function [K_path,K_labelindex]=make_path(k_high_sym,step)
            %k_high_sym: the high-symmetry path in BZ
            %step: the minimal distance between 2 k points we calculate
            %K_path: the matrix that store the position of all k-points
            %K_labelindex: the index of the high-sym-point in k-path
            kpoint_num=length(k_high_sym);
            K_path=[];
            K_labelindex=zeros(1,kpoint_num);
            for i=1:kpoint_num-1
                d=norm(k_high_sym{i+1}-k_high_sym{i});
                n=round(d/step);
                r1=k_high_sym{i}*[1;1i];
                r2=k_high_sym{i+1}*[1;1i];
                tem=linspace(r1,r2,n+1);
                tem(end)=[];
                kx=real(tem);ky=imag(tem);
                kx=kx';ky=ky';
                K_path=[K_path;kx,ky];
                K_labelindex(i+1)=n+K_labelindex(i);
            end
            K_labelindex=K_labelindex+1;
            K_labelindex(end)=K_labelindex(end)-1;
end