 function [Kpath,Kindex]=classic_kpath(knum,Gm1,Gm2)
            K1=(Gm1+2.*Gm2)/3;
            K2=(2.*Gm1+Gm2)/3;
            KM=(Gm1+Gm2)/2;
            Gamma=[0,0];
            kpath={Gamma;KM;K1;Gamma};            
            step=norm(kpath{2}-kpath{1})/knum;
            [Kpath,Kindex]=common.BZ.make_path(kpath,step);
end